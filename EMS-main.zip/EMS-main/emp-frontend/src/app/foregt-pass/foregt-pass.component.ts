import { Component } from '@angular/core';

@Component({
  selector: 'app-foregt-pass',
  templateUrl: './foregt-pass.component.html',
  styleUrls: ['./foregt-pass.component.css']
})
export class ForegtPassComponent {

}
